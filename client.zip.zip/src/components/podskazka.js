import React from "react";
class Pod extends React.Component{
    render(){
        return(
            <div className="name">
                    


            </div>
        )}


}

export default Pod